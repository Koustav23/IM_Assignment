package empiresage;

import java.util.ArrayList;
import java.util.HashMap;
import ageofempiresgui.*;
import javax.swing.SwingWorker;
import java.util.List;


public class EmpiresAge  extends SwingWorker <List<HashMap>, HashMap> {


    public HashMap <String,Integer> gameState;
    private MinMaxPlayer minMax;
    private MCTSPlayer mscts;
    private gameGUI gg;
    String[] props ;
    
    public EmpiresAge()
    {
        props = new String[]{"numberOfVillagersPlayer","numberOfFightersPlayer","numberOfHousesPlayer",
                        "numberOfFightingUnit","woodPlayer","foodPlayer"};
        initialize();
    }
    
    public void setUI(gameGUI gg)
    {
        this.gg = gg;
    }
    
            
    public void initialize() {
        gameState = new HashMap <String,Integer>();
        gameState.put("numberOfVillagersPlayerOne", 10);
        gameState.put("numberOfVillagersPlayerTwo", 10);
        gameState.put("numberOfFightersPlayerOne", 20);
        gameState.put("numberOfFightersPlayerTwo", 20);
        gameState.put("numberOfHousesPlayerOne", 10);
        gameState.put("numberOfHousesPlayerTwo", 10);
        gameState.put("numberOfFightingUnitOne", 10);
        gameState.put("numberOfFightingUnitTwo", 10);
        gameState.put("woodPlayerOne", 0);
        gameState.put("woodPlayerTwo", 0);
        gameState.put("foodPlayerOne", 0);
        gameState.put("foodPlayerTwo", 0);
        
    }
    
    
    public HashMap <String,Integer> getGameState() {return gameState;}
    
    public boolean isRunning()
    {
        return (!mscts.endGame(gameState) && !minMax.endGame(gameState));
    }
    
    
    public void runGame()
    {
        
        //HashMap <String,Integer> state2 = (HashMap) state.clone();
        //HashMap <String,Integer> state3 = (HashMap) state.clone();

        boolean minmaxAnnounced=false;
        boolean mctsAnnounced= false;
        
        // MiniMax VS MCTS
        minMax = new MinMaxPlayer(gameState,1);       
        mscts = new MCTSPlayer(gameState,2);
        while (!mscts.endGame(gameState) && !minMax.endGame(gameState))
        {
           gameState= mscts.updateMove(gameState);
           mscts.setState(gameState);
           minMax.setState(gameState);
           gameState = minMax.updateMove(gameState);
           mscts.setState(gameState);
           minMax.setState(gameState);
           if (!minmaxAnnounced && minMax.endGame(gameState)) 
           	{
        	 System.out.println("minmax finished");
        	 minmaxAnnounced=true;
           	}
           
           if (!mctsAnnounced && mscts.endGame(gameState)) 
          	{
        	   System.out.println("mcts finished");
        	   mctsAnnounced=true;
          	}
           publish(gameState);
        }
        
        if(minMax.endGame(gameState)){
            System.out.println("And the winner of the battle between Minimax and MCTS is MiniMax");
        }
        if(mscts.endGame(gameState)){
            System.out.println("And the winner of the battle between Minimax and MCTS is MCTS");
        }

    }
    


    @Override
    protected List<HashMap> doInBackground() throws Exception {
        System.out.println("doing it");
        runGame();
        return null;
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
     protected void process(List<HashMap> hms) {
         for (HashMap hm : hms) {
             gg.showState(hm);
         }
     }

    
}
