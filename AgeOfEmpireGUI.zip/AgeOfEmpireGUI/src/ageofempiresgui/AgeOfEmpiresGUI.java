package ageofempiresgui;
import empiresage.*;


public class AgeOfEmpiresGUI {


    public static void main(String[] args) {
        // TODO code application logic here
        java.awt.EventQueue.invokeLater(new Runnable() {
            
            public void run() {
                
                gameGUI gg = new gameGUI();
                gg.setVisible(true);
            }
        });
    }
    
}
